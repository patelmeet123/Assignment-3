<?php
$username = filter_input(INPUT_POST, 'username');
$password = filter_input(INPUT_POST, 'password');
$email = filter_input(INPUT_POST, 'email');
$feedback = filter_input(INPUT_POST, 'feedback');
$rating = filter_input(INPUT_POST, 'rating');
$department = filter_input(INPUT_POST, 'department');
$college = filter_input(INPUT_POST, 'college'); // Added college input

if (!empty($username) && !empty($password)) {
    $host = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname = "form";
    $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);

    if (mysqli_connect_error()) {
        die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
    } else {
        $sql = "INSERT INTO account (username, password, email, feedback, rating, department, college)
                VALUES ('$username', '$password', '$email', '$feedback', '$rating', '$department', '$college')";
        if ($conn->query($sql)) {
            echo "New record is inserted successfully";
        } else {
            echo "Error: " . $sql . " " . $conn->error;
        }
        $conn->close();
    }
} else {
    echo "Username and Password should not be empty";
    die();
}
?>
